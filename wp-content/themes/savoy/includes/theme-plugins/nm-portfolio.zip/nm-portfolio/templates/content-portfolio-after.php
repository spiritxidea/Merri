    </ul>
</div>

<?php do_action( 'nm_portfolio_after' ); ?>
